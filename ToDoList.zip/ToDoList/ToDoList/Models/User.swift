//
//  User.swift
//  ToDoList
//
//  Created by WSLT82 on 03/03/24.
//

import Foundation

struct User: Codable{
    let id: String
    let name: String
    let email: String
    let joined: TimeInterval
}
