//
//  ToDoListApp.swift
//  ToDoList
//
//  Created by WSLT82 on 23/02/24.
//

import FirebaseCore
import SwiftUI

@main
struct ToDoListApp: App {
    init(){
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
